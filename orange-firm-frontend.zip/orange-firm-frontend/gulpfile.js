var gulp = require('gulp'),
    pump = require('pump'),
    gulpLoadPlugins = require('gulp-load-plugins'),
    $ = gulpLoadPlugins(),
    browserSync = require('browser-sync').create(),
    reload = browserSync.reload;

gulp.task('useref', function (cb) {
    var options = {
        removeComments: true,//清除HTML注释
        collapseWhitespace: true,//压缩HTML
        collapseBooleanAttributes: true,//省略布尔属性的值 <input checked="true"/> ==> <input />
        removeEmptyAttributes: true,//删除所有空格作属性值 <input id="" /> ==> <input />
        removeScriptTypeAttributes: true,//删除<script>的type="text/javascript"
        removeStyleLinkTypeAttributes: true,//删除<style>和<link>的type="text/css"
        minifyJS: true,//压缩页面JS
        minifyCSS: true//压缩页面CSS
    },
    version = Math.round(new Date());

    pump([
     gulp.src('src/index.html'),
        $.useref(),
        //.pipe($.if('*.js', $.uglify()))
        //.pipe($.if('*.css', $.cleanCss()))
        //.pipe($.replace('.css"', '.css?v=' + version + '"'))
        //.pipe($.replace('.js"', '.js?v=' + version + '"'))
        $.if('*.js', $.uglify().on('error', function(err){
            $.util.log(err);
            this.emit('end');
        })),
        $.if('*.js', $.rev()),
        $.if('*.css', $.cleanCss()),
        $.if('*.css', $.rev()),
        $.revReplace({}),
        $.if('*.html', $.htmlmin(options)),
        gulp.dest('dist')
        ], cb);
});

gulp.task('less', function () {
    return gulp.src('src/css/all.less')
        .pipe($.plumber({errorHandler: $.notify.onError('Error: <%= error.message %>')}))
        .pipe($.less())
        .pipe(gulp.dest('src/css/'))
});

//拷贝七牛
gulp.task('qiniu', function () {
    return gulp.src('src/js/qiniu/js/*.js')
        .pipe($.uglify().on('error', function(err){
            $.util.log(err);
            this.emit('end');
        }))
        .pipe(gulp.dest('dist/js/qiniu/js/'));
});

//压缩图片
gulp.task('minImages', function () {
    return gulp.src(['src/images/**/*.png', 'src/images/**/*.jpg', 'src/images/**/*.gif', 'src/images/**/*.ico'])
        .pipe($.cache($.imagemin({
            optimizationLevel: 5,
            progressive: true,
            interlaced: true
        })))
        .pipe(gulp.dest('dist/images'));
});

//拷贝字体
gulp.task('fonts', function () {
    return gulp.src('src/fonts/glyphicons-halflings-regular.*')
        .pipe(gulp.dest('dist/fonts/'));
});

//拷贝字体
gulp.task('fonts2', function () {
    return gulp.src('src/fonts/icomoon.*')
        .pipe(gulp.dest('dist/css/fonts/'));
});

//拷贝choosen图片
gulp.task('choosenPic', function () {
    return gulp.src('src/css/*.png')
        .pipe(gulp.dest('dist/css/'));
});
//拷贝jquery-ui图片
gulp.task('jqueryUiPic', function () {
    return gulp.src('bower_components/datetimepicker/images/*.png')
        .pipe(gulp.dest('dist/css/images/'));
});
//拷贝数据文件
gulp.task('data', function () {
    return gulp.src('src/data/*')
        .pipe(gulp.dest('dist/data/'));
});

//拷贝模版js
gulp.task('tpl', function () {
    return gulp.src('src/tpl/**/*')
        .pipe($.if('*.js', $.uglify().on('error', function(err){
            $.util.log(err);
            this.emit('end');
        })))
        .pipe(gulp.dest('dist/tpl/'));
});

//拷贝资源
gulp.task('static', function () {
    return gulp.src('src/static/**/*')
        .pipe(gulp.dest('dist/static/'));
});

//清理文件夹
gulp.task('clean', function () {
    return gulp.src(['dist/', 'rev-manifest.json'])
        .pipe($.clean());
});

gulp.task('default',['less', 'revCollector'], function () {
    gulp.start('useref', 'qiniu', 'minImages', 'fonts', 'data', 'choosenPic', 'jqueryUiPic', 'fonts2', 'static');
});

gulp.task('server', ['less'], function () {
    browserSync.init({
        server: "./"
    });
    gulp.watch("src/css/*.less", ['less']);
    gulp.watch("src/**").on('change', reload);
});

//生成精灵图
gulp.task('sprite', function () {
    return gulp.src('src/images/nav/*.png')
        .pipe($.spritesmith({imgName: 'icon-nav.png', cssName: 'icon-nav.css' }))
        .pipe(gulp.dest('src/images/nav/'));
});

//给路由应用文件添加版本控制
gulp.task('routerRev', function() {
    const f = $.filter(['**', '!src/tpl/base/*.html','!src/tpl/base/modal/**/*'], {restore: true});
    return gulp.src('src/tpl/**/*')
        .pipe($.if('*.js', $.uglify().on('error', function(err){
            $.util.log(err);
            this.emit('end');
        })))
        .pipe(f)
        .pipe($.rev())
        .pipe(f.restore)
        .pipe(gulp.dest('dist/tpl/'))
        .pipe($.rev.manifest())
        .pipe(gulp.dest('./'))

});
gulp.task('revCollector', ['routerRev'], function() {
    return gulp.src(['rev-manifest.json', 'src/js/base/configRouter.js'])
        .pipe($.revCollector({
            replaceReved:true
        }))
        .pipe(gulp.dest('src/js/base/'));
    }
);